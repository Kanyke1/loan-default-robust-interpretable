#!/usr/bin/env bash
# Create a single archive containing SSE manager, task control, example FastAPI integration,
# and a React + Vite frontend with SSE hooks, logs widget, and updated panels.
#
# Usage:
#   chmod +x create_archive.sh
#   ./create_archive.sh
# This will produce sse-live-progress.tar.gz in the current directory containing the files.

set -euo pipefail

ROOT="sse-live-progress"
FRONTEND="$ROOT/frontend"
APPDIR="$ROOT/app"
SRC="$FRONTEND/src"
COMPONENTS="$SRC/components"
HOOKS="$SRC/hooks"

echo "Removing any previous directory $ROOT ..."
rm -rf "$ROOT" sse-live-progress.tar.gz

echo "Creating directory structure..."
mkdir -p "$APPDIR"
mkdir -p "$FRONTEND"
mkdir -p "$SRC"
mkdir -p "$COMPONENTS"
mkdir -p "$HOOKS"

# (The script writes all prepared files. Use the one I gave earlier or run the version you already have.)
# If you already have create_archive.sh from earlier, run it. Otherwise paste the full script I gave previously.
echo "If you already have the create_archive.sh script from earlier, run it now to build sse-live-progress.tar.gz."