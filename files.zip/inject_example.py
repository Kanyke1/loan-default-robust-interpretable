# Example: integrate into your existing function
# from app.sse import manager            # or from app.sse_redis import manager_instance when using Redis
# from app.task_control import task_manager  # or RedisTaskManager

async def my_preprocess(task_id, ...):
    await manager.broadcast({"type":"progress","task":"preprocess","pct":0,"msg":"starting","task_id":task_id})
    # load files
    df = load_and_merge_csvs(...)
    await manager.broadcast({"type":"progress","task":"preprocess","pct":10,"msg":"loaded CSVs","task_id":task_id})
    if await task_manager.is_cancelled(task_id):
        await manager.broadcast({"type":"error","task":"preprocess","msg":"cancelled","task_id":task_id})
        return
    # feature engineering: send updates inside loops
    for i, step in enumerate(steps):
        do_step(step)
        pct = 10 + int((i+1)/len(steps)*80)
        await manager.broadcast({"type":"progress","task":"preprocess","pct":pct,"msg":f"step {i+1}/{len(steps)}","task_id":task_id})
        if await task_manager.is_cancelled(task_id):
            await manager.broadcast({"type":"error","task":"preprocess","msg":"cancelled","task_id":task_id})
            return
    save_processed(df)
    await manager.broadcast({"type":"progress","task":"preprocess","pct":100,"msg":"finished","task_id":task_id,"result": {"processed_path":"data/processed/train.csv"}})