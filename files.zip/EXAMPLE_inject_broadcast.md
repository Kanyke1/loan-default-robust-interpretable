```markdown
## Example injection pattern (copy into your preprocessing/training code)

Assume you have functions:
- app/pipeline.py: def run_preprocess(...)
- app/train.py: def run_train(...)

Import manager (Redis or in-memory) and task_manager as appropriate.
Here's a minimal pattern:

from app.sse import manager            # or from app.sse_redis import RedisEventManager-managed instance
from app.task_control import task_manager  # or RedisTaskManager

async def run_preprocess_job(task_id: str, ...):
    # before long work:
    await manager.broadcast({"type":"progress","task":"preprocess","pct":0,"msg":"starting","task_id":task_id})

    # loading
    df = load_csvs(...)
    await manager.broadcast({"type":"progress","task":"preprocess","pct":10,"msg":"loaded csvs","task_id":task_id})
    if await task_manager.is_cancelled(task_id):
        await manager.broadcast({"type":"error","task":"preprocess","msg":"cancelled","task_id":task_id})
        return

    # feature engineering - inside loops, send updates
    for i, step in enumerate(steps):
        do_step(step)
        pct = 10 + int((i+1)/len(steps)*70)
        await manager.broadcast({"type":"progress","task":"preprocess","pct":pct,"msg":f"step {i+1}/{len(steps)}","task_id":task_id})
        if await task_manager.is_cancelled(task_id):
            await manager.broadcast({"type":"error","task":"preprocess","msg":"cancelled","task_id":task_id})
            return

    save_processed(...)
    await manager.broadcast({"type":"progress","task":"preprocess","pct":100,"msg":"finished","task_id":task_id,"result":{"processed_path":"data/processed/train.csv"}})